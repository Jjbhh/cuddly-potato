package net.stark.combat;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CombatPlugin extends JavaPlugin {
    private ZoneManager zones;
    private CombatManager combat;
    private WallRenderer walls;
    private NamespacedKey wandKey;
    private final Map<UUID, Location> pos1 = new HashMap<>();
    private final Map<UUID, Location> pos2 = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new java.io.File(getDataFolder(), "zones.yml").exists()) {
            saveResource("zones.yml", false);
        }
        wandKey = new NamespacedKey(this, "wand");
        zones = new ZoneManager(this);
        zones.load();
        walls = new WallRenderer(this);
        combat = new CombatManager(this);

        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new WandListener(this), this);

        PluginCommand cmd = getCommand("combat");
        if (cmd != null) {
            ZoneCommand zc = new ZoneCommand(this);
            cmd.setExecutor(zc);
            cmd.setTabCompleter(zc);
        }
        combat.startTask();
        getLogger().info("CombatTag enabled - " + zones.all().size() + " zone(s) loaded");
    }

    @Override
    public void onDisable() {
        if (walls != null) walls.clearAll();
        if (combat != null) combat.shutdown();
        if (zones != null) zones.save();
    }

    public ZoneManager zones() { return zones; }
    public CombatManager combat() { return combat; }
    public WallRenderer walls() { return walls; }
    public NamespacedKey wandKey() { return wandKey; }
    public Map<UUID, Location> pos1() { return pos1; }
    public Map<UUID, Location> pos2() { return pos2; }

    public Component component(String text) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(text);
    }

    private String fill(String key, String... repl) {
        String s = getConfig().getString("messages." + key, key);
        for (int i = 0; i + 1 < repl.length; i += 2) s = s.replace(repl[i], repl[i + 1]);
        return s;
    }

    /** Message without prefix (for the action bar) */
    public Component raw(String key, String... repl) {
        return component(fill(key, repl));
    }

    /** Message with prefix */
    public Component msg(String key, String... repl) {
        return component(getConfig().getString("messages.prefix", "") + fill(key, repl));
    }
}
