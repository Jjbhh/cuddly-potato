package net.stark.combat;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class ZoneCommand implements CommandExecutor, TabCompleter {
    private final CombatPlugin plugin;

    public ZoneCommand(CombatPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!s.hasPermission("stark.combat.admin")) {
            s.sendMessage(plugin.component("&cYou do not have permission"));
            return true;
        }
        if (a.length == 0) {
            help(s);
            return true;
        }
        switch (a[0].toLowerCase()) {
            case "wand" -> {
                if (!(s instanceof Player p)) {
                    s.sendMessage("Players only");
                    return true;
                }
                ItemStack it = new ItemStack(Material.GOLDEN_AXE);
                ItemMeta m = it.getItemMeta();
                m.displayName(plugin.component("&6Combat Zone Wand").decoration(TextDecoration.ITALIC, false));
                m.lore(List.of(
                        plugin.component("&7Left click = Pos1").decoration(TextDecoration.ITALIC, false),
                        plugin.component("&7Right click = Pos2").decoration(TextDecoration.ITALIC, false)));
                m.getPersistentDataContainer().set(plugin.wandKey(), PersistentDataType.BYTE, (byte) 1);
                it.setItemMeta(m);
                p.getInventory().addItem(it);
                p.sendMessage(plugin.component("&a✔ You received the wand"));
            }
            case "create" -> {
                if (!(s instanceof Player p)) {
                    s.sendMessage("Players only");
                    return true;
                }
                if (a.length < 2) {
                    s.sendMessage(plugin.component("&c/combat create <name>"));
                    return true;
                }
                Location p1 = plugin.pos1().get(p.getUniqueId());
                Location p2 = plugin.pos2().get(p.getUniqueId());
                if (p1 == null || p2 == null) {
                    s.sendMessage(plugin.component("&cSelect Pos1 and Pos2 with the wand first"));
                    return true;
                }
                if (!p1.getWorld().equals(p2.getWorld())) {
                    s.sendMessage(plugin.component("&cBoth positions must be in the same world"));
                    return true;
                }
                if (plugin.zones().create(a[1], p1, p2)) {
                    s.sendMessage(plugin.component("&a✔ Zone created: &f" + a[1]));
                } else {
                    s.sendMessage(plugin.component("&cA zone with that name already exists"));
                }
            }
            case "delete" -> {
                if (a.length < 2) {
                    s.sendMessage(plugin.component("&c/combat delete <name>"));
                    return true;
                }
                if (plugin.zones().delete(a[1])) {
                    s.sendMessage(plugin.component("&a✔ Zone deleted: &f" + a[1]));
                } else {
                    s.sendMessage(plugin.component("&cZone not found"));
                }
            }
            case "list" -> {
                if (plugin.zones().all().isEmpty()) {
                    s.sendMessage(plugin.component("&7No zones defined"));
                    return true;
                }
                for (Zone z : plugin.zones().all()) {
                    s.sendMessage(plugin.component("&e" + z.name + " &7(" + z.world + ") &f"
                            + z.minX + "," + z.minY + "," + z.minZ + " → " + z.maxX + "," + z.maxY + "," + z.maxZ));
                }
            }
            case "reload" -> {
                plugin.reloadConfig();
                plugin.zones().load();
                s.sendMessage(plugin.component("&a✔ Reloaded"));
            }
            default -> help(s);
        }
        return true;
    }

    private void help(CommandSender s) {
        s.sendMessage(plugin.component("&6/combat wand &7- selection wand"));
        s.sendMessage(plugin.component("&6/combat create <name> &7- create a restricted zone"));
        s.sendMessage(plugin.component("&6/combat delete <name> &7- delete a zone"));
        s.sendMessage(plugin.component("&6/combat list &7- list zones"));
        s.sendMessage(plugin.component("&6/combat reload &7- reload config and zones"));
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String o : List.of("wand", "create", "delete", "list", "reload")) {
                if (o.startsWith(a[0].toLowerCase())) out.add(o);
            }
        } else if (a.length == 2 && a[0].equalsIgnoreCase("delete")) {
            for (Zone z : plugin.zones().all()) {
                if (z.name.toLowerCase().startsWith(a[1].toLowerCase())) out.add(z.name);
            }
        }
        return out;
    }
}
