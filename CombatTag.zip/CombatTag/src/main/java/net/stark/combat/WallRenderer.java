package net.stark.combat;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class WallRenderer {
    private final CombatPlugin plugin;
    private final Map<UUID, Set<Location>> shown = new HashMap<>();

    public WallRenderer(CombatPlugin plugin) {
        this.plugin = plugin;
    }

    public void update(Player p) {
        int r = plugin.getConfig().getInt("wall.view-distance", 5);
        Material mat = Material.matchMaterial(plugin.getConfig().getString("wall.material", "RED_STAINED_GLASS"));
        if (mat == null || !mat.isBlock()) mat = Material.RED_STAINED_GLASS;
        BlockData fake = mat.createBlockData();

        World w = p.getWorld();
        Location pl = p.getLocation();
        int px = pl.getBlockX(), py = pl.getBlockY(), pz = pl.getBlockZ();
        Set<Location> now = new HashSet<>();

        for (Zone zone : plugin.zones().all()) {
            if (!zone.world.equals(w.getName())) continue;
            if (zone.contains(pl)) continue;
            if (px < zone.minX - r || px > zone.maxX + r) continue;
            if (py < zone.minY - r || py > zone.maxY + r) continue;
            if (pz < zone.minZ - r || pz > zone.maxZ + r) continue;

            int x0 = Math.max(zone.minX, px - r), x1 = Math.min(zone.maxX, px + r);
            int y0 = Math.max(zone.minY, py - r), y1 = Math.min(zone.maxY, py + r);
            int z0 = Math.max(zone.minZ, pz - r), z1 = Math.min(zone.maxZ, pz + r);

            // Only the vertical side walls, and only the face the player is
            // outside of and close to (no floor/ceiling, no far side).
            if (px < zone.minX || px > zone.maxX) {
                int fx = px < zone.minX ? zone.minX : zone.maxX;
                if (Math.abs(px - fx) <= r) addFace(w, now, fx, fx, y0, y1, z0, z1);
            }
            if (pz < zone.minZ || pz > zone.maxZ) {
                int fz = pz < zone.minZ ? zone.minZ : zone.maxZ;
                if (Math.abs(pz - fz) <= r) addFace(w, now, x0, x1, y0, y1, fz, fz);
            }
        }

        Set<Location> old = shown.getOrDefault(p.getUniqueId(), Collections.emptySet());
        for (Location l : now) {
            if (!old.contains(l)) p.sendBlockChange(l, fake);
        }
        for (Location l : old) {
            if (!now.contains(l)) restore(p, l);
        }
        if (now.isEmpty()) shown.remove(p.getUniqueId());
        else shown.put(p.getUniqueId(), now);
    }

    private void addFace(World w, Set<Location> out, int xa, int xb, int ya, int yb, int za, int zb) {
        for (int x = xa; x <= xb; x++) {
            for (int y = ya; y <= yb; y++) {
                for (int z = za; z <= zb; z++) {
                    if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
                    Block b = w.getBlockAt(x, y, z);
                    if (!b.getType().isAir()) continue;
                    out.add(b.getLocation());
                }
            }
        }
    }

    private void restore(Player p, Location l) {
        if (l.getWorld() == null || !l.getWorld().equals(p.getWorld())) return;
        p.sendBlockChange(l, l.getBlock().getBlockData());
    }

    public void clear(Player p) {
        Set<Location> old = shown.remove(p.getUniqueId());
        if (old == null) return;
        for (Location l : old) restore(p, l);
    }

    public void forget(UUID id) {
        shown.remove(id);
    }

    public void clearAll() {
        for (Player p : Bukkit.getOnlinePlayers()) clear(p);
        shown.clear();
    }
}
