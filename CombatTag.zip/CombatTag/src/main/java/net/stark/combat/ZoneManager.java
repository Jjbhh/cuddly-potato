package net.stark.combat;

import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

public class ZoneManager {
    private final CombatPlugin plugin;
    private final File file;
    private final Map<String, Zone> zones = new LinkedHashMap<>();

    public ZoneManager(CombatPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "zones.yml");
    }

    public void load() {
        zones.clear();
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = yml.getConfigurationSection("zones");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(key);
            if (s == null) continue;
            Zone z = new Zone(key, s.getString("world", "world"),
                    s.getInt("min.x", s.getInt("min-x")), s.getInt("min.y", s.getInt("min-y")), s.getInt("min.z", s.getInt("min-z")),
                    s.getInt("max.x", s.getInt("max-x")), s.getInt("max.y", s.getInt("max-y")), s.getInt("max.z", s.getInt("max-z")));
            zones.put(key.toLowerCase(), z);
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Zone z : zones.values()) {
            String p = "zones." + z.name + ".";
            yml.set(p + "world", z.world);
            yml.set(p + "min.x", z.minX);
            yml.set(p + "min.y", z.minY);
            yml.set(p + "min.z", z.minZ);
            yml.set(p + "max.x", z.maxX);
            yml.set(p + "max.y", z.maxY);
            yml.set(p + "max.z", z.maxZ);
        }
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to save zones.yml: " + e.getMessage());
        }
    }

    public boolean create(String name, Location a, Location b) {
        if (zones.containsKey(name.toLowerCase())) return false;
        Zone z = new Zone(name, a.getWorld().getName(),
                a.getBlockX(), a.getBlockY(), a.getBlockZ(),
                b.getBlockX(), b.getBlockY(), b.getBlockZ());
        zones.put(name.toLowerCase(), z);
        save();
        return true;
    }

    public boolean delete(String name) {
        Zone z = zones.remove(name.toLowerCase());
        if (z == null) return false;
        save();
        return true;
    }

    public Collection<Zone> all() {
        return zones.values();
    }

    public boolean isInAny(Location l) {
        for (Zone z : zones.values()) {
            if (z.contains(l)) return true;
        }
        return false;
    }
}
