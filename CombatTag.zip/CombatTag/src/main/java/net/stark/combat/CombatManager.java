package net.stark.combat;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class CombatManager {
    private final CombatPlugin plugin;
    private final Map<UUID, Long> tags = new HashMap<>();
    private final Map<UUID, String> opponents = new HashMap<>();
    private final Set<UUID> loggedOut = new HashSet<>();

    public CombatManager(CombatPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isTagged(UUID id) {
        Long e = tags.get(id);
        return e != null && e > System.currentTimeMillis();
    }

    public int remaining(UUID id) {
        Long e = tags.get(id);
        if (e == null) return 0;
        long ms = e - System.currentTimeMillis();
        return ms <= 0 ? 0 : (int) Math.ceil(ms / 1000.0);
    }

    public void tag(Player p, Player opponent) {
        if (p.hasPermission("stark.combat.bypass")) return;
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return;
        int duration = plugin.getConfig().getInt("combat-duration", 15);
        UUID id = p.getUniqueId();
        boolean was = isTagged(id);
        tags.put(id, System.currentTimeMillis() + duration * 1000L);
        opponents.put(id, opponent.getName());
        if (!was) {
            p.sendMessage(plugin.msg("tagged", "{time}", String.valueOf(duration)));
        }
        sendActionBar(p);
    }

    private String buildBar(float progress) {
        int length = Math.max(1, plugin.getConfig().getInt("actionbar.length", 20));
        String ch = plugin.getConfig().getString("actionbar.char", "█");
        String full = plugin.getConfig().getString("actionbar.full-color", "&c");
        String empty = plugin.getConfig().getString("actionbar.empty-color", "&7");
        int filled = Math.round(progress * length);
        filled = Math.min(length, Math.max(0, filled));
        return full + ch.repeat(filled) + empty + ch.repeat(length - filled);
    }

    private void sendActionBar(Player p) {
        UUID id = p.getUniqueId();
        Long exp = tags.get(id);
        if (exp == null) return;
        long total = plugin.getConfig().getInt("combat-duration", 15) * 1000L;
        long left = Math.max(0, exp - System.currentTimeMillis());
        float progress = total <= 0 ? 0f : Math.min(1f, Math.max(0f, left / (float) total));
        p.sendActionBar(plugin.raw("actionbar",
                "{time}", String.valueOf(remaining(id)),
                "{bar}", buildBar(progress),
                "{player}", opponents.getOrDefault(id, "?")));
    }

    public void untag(Player p, boolean notify) {
        if (tags.remove(p.getUniqueId()) != null) {
            opponents.remove(p.getUniqueId());
            plugin.walls().clear(p);
            p.sendActionBar(plugin.component(" "));
            if (notify) p.sendMessage(plugin.msg("ended"));
        }
    }

    public void remove(UUID id) {
        tags.remove(id);
        opponents.remove(id);
    }

    public void markLoggedOut(UUID id) {
        loggedOut.add(id);
    }

    public boolean consumeLoggedOut(UUID id) {
        return loggedOut.remove(id);
    }

    public void startTask() {
        long ticks = Math.max(1, plugin.getConfig().getLong("wall.update-ticks", 5L));
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, ticks, ticks);
    }

    public void shutdown() {
        tags.clear();
        opponents.clear();
    }

    private void tick() {
        for (UUID id : new ArrayList<>(tags.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p == null || !p.isOnline()) {
                remove(id);
                continue;
            }
            if (!isTagged(id)) {
                untag(p, true);
                continue;
            }
            sendActionBar(p);
            plugin.walls().update(p);
        }
    }
}
