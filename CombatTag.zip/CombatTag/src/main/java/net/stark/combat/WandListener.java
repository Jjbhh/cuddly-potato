package net.stark.combat;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

public class WandListener implements Listener {
    private final CombatPlugin plugin;

    public WandListener(CombatPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a != Action.LEFT_CLICK_BLOCK && a != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack it = e.getItem();
        if (it == null || !it.hasItemMeta()) return;
        if (!it.getItemMeta().getPersistentDataContainer().has(plugin.wandKey(), PersistentDataType.BYTE)) return;
        Player p = e.getPlayer();
        if (!p.hasPermission("stark.combat.admin")) return;
        e.setCancelled(true);
        Location l = e.getClickedBlock().getLocation();
        String pos = l.getBlockX() + " " + l.getBlockY() + " " + l.getBlockZ();
        if (a == Action.LEFT_CLICK_BLOCK) {
            plugin.pos1().put(p.getUniqueId(), l);
            p.sendMessage(plugin.component("&a✔ Pos1: &f" + pos));
        } else {
            plugin.pos2().put(p.getUniqueId(), l);
            p.sendMessage(plugin.component("&a✔ Pos2: &f" + pos));
        }
    }
}
