package net.stark.combat;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.projectiles.ProjectileSource;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CombatListener implements Listener {
    private final CombatPlugin plugin;
    private final Map<UUID, Long> lastBlockedMsg = new HashMap<>();

    public CombatListener(CombatPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker = null;
        Entity d = e.getDamager();
        if (d instanceof Player pd) {
            attacker = pd;
        } else if (d instanceof Projectile proj) {
            ProjectileSource src = proj.getShooter();
            if (src instanceof Player ps) attacker = ps;
        }
        if (attacker == null || attacker.equals(victim)) return;
        plugin.combat().tag(victim, attacker);
        plugin.combat().tag(attacker, victim);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        boolean tagged = plugin.combat().isTagged(id);
        plugin.walls().forget(id);
        plugin.combat().remove(id);
        lastBlockedMsg.remove(id);
        if (!tagged) return;

        if (plugin.getConfig().getBoolean("hide-logout-quit-message", true)) {
            e.quitMessage(null);
        }
        plugin.combat().markLoggedOut(id);
        Location loc = p.getLocation();
        loc.getWorld().strikeLightningEffect(loc);
        p.setHealth(0.0);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        plugin.combat().untag(p, false);
        boolean wasLogout = plugin.combat().consumeLoggedOut(p.getUniqueId());
        if (wasLogout && plugin.getConfig().getBoolean("hide-logout-death-message", true)) {
            e.deathMessage(null);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) return;
        if (from.getBlockX() == to.getBlockX() && from.getBlockY() == to.getBlockY()
                && from.getBlockZ() == to.getBlockZ()) return;
        Player p = e.getPlayer();
        if (!plugin.combat().isTagged(p.getUniqueId())) return;
        if (plugin.zones().isInAny(to) && !plugin.zones().isInAny(from)) {
            e.setCancelled(true);
            notifyBlocked(p);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        Location to = e.getTo();
        if (to == null) return;
        Player p = e.getPlayer();
        if (!plugin.combat().isTagged(p.getUniqueId())) return;
        if (plugin.zones().isInAny(to) && !plugin.zones().isInAny(e.getFrom())) {
            e.setCancelled(true);
            notifyBlocked(p);
        }
    }

    private void notifyBlocked(Player p) {
        long now = System.currentTimeMillis();
        Long last = lastBlockedMsg.get(p.getUniqueId());
        if (last != null && now - last < 1500) return;
        lastBlockedMsg.put(p.getUniqueId(), now);
        p.sendMessage(plugin.msg("zone-blocked"));
    }
}
